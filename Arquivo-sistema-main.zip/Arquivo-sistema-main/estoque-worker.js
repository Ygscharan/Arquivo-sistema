/* Web Worker: parse/stringify de JSON pesado fora da thread principal */
self.onmessage = function(ev) {
    const { op, id } = ev.data;
    try {
        if (op === "parse") {
            const text = ev.data.text;
            self.postMessage({ id, result: text ? JSON.parse(text) : [] });
        } else if (op === "stringify") {
            self.postMessage({ id, result: JSON.stringify(ev.data.data) });
        } else {
            self.postMessage({ id, error: "Operação desconhecida: " + op });
        }
    } catch (e) {
        self.postMessage({ id, error: e.message || String(e) });
    }
};
